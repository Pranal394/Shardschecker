const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const unzipper = require('unzipper');

let mainWindow;
let registeredGames = [];

// URLs for updater + game registry
const appVersionUrl = "https://raw.githubusercontent.com/Pranal394/Shardschecker/main/version.txt";
const remoteRegistryUrl = "https://raw.githubusercontent.com/Pranal394/Shardschecker/main/game-versions.json";
const updaterZipUrl = "https://raw.githubusercontent.com/Pranal394/Shardschecker/main/ShardsConnect.zip";

// Create main window
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });
  mainWindow.loadFile("preloader.html");
}

app.on("ready", createWindow);

// --- Helpers ---
function fetchText(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let data = "";
      res.on("data", chunk => (data += chunk));
      res.on("end", () => resolve(data.trim()));
      res.on("error", reject);
    }).on("error", reject);
  });
}

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      let data = "";
      res.on("data", chunk => (data += chunk));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch (err) {
          reject(err);
        }
      });
      res.on("error", reject);
    }).on("error", reject);
  });
}

// --- IPC Handlers ---

// Preloader: check updater version
ipcMain.handle("check-updater-version", async () => {
  try {
    const remoteVersion = await fetchText(appVersionUrl);
    const localVersion = require("./package.json").version;
    return { localVersion, remoteVersion };
  } catch (err) {
    return { error: err.message };
  }
});

// Preloader: run updater update
ipcMain.handle("run-app-update", async () => {
  try {
    const zipPath = path.join(app.getPath("temp"), "ShardsConnect.zip");

    return new Promise((resolve, reject) => {
      https.get(updaterZipUrl, res => {
        const fileStream = fs.createWriteStream(zipPath);
        res.pipe(fileStream);

        fileStream.on("finish", () => {
          fileStream.close();

          fs.createReadStream(zipPath)
            .pipe(unzipper.Extract({ path: app.getAppPath() }))
            .on("close", () => {
              fs.unlinkSync(zipPath);
              resolve({ status: "updated" });
            })
            .on("error", err => reject({ status: "error", message: err.message }));
        });
      }).on("error", err => reject({ status: "error", message: err.message }));
    });
  } catch (err) {
    return { status: "error", message: err.message };
  }
});

// Preloader: continue to main app
ipcMain.on("load-main-app", () => {
  if (mainWindow) {
    mainWindow.loadFile("app.html");
  }
});

// Fetch remote game registry
ipcMain.handle("fetch-remote-registry", async () => {
  try {
    const registry = await fetchJSON(remoteRegistryUrl);
    return registry;
  } catch (err) {
    return {};
  }
});

// Browse for directory
ipcMain.handle("select-directory", async () => {
  const result = await dialog.showOpenDialog({
    properties: ["openDirectory"]
  });
  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0];
  }
  return null;
});

// Register game
ipcMain.handle("register-game", async (event, { name, dir }) => {
  try {
    const markerFile = path.join(dir, "ShardsConnect-Service.json");
    const markerData = { game: name, version: "1.0.0", dir };
    fs.writeFileSync(markerFile, JSON.stringify(markerData, null, 2));
    registeredGames.push(markerData);
    return { status: "ok", message: `${name} registered at ${dir}` };
  } catch (err) {
    return { status: "error", message: err.message };
  }
});

// List registered games
ipcMain.handle("list-games", async () => {
  return registeredGames;
});

// Update game
ipcMain.handle("update-game", async (event, { game, dir, link, version }) => {
  const zipPath = path.join(app.getPath("temp"), `${game}-update.zip`);
  const markerFile = path.join(dir, "ShardsConnect-Service.json");

  // ✅ Check if service file exists before updating
  if (!fs.existsSync(markerFile)) {
    log.warn(`Service file missing for ${game}. Skipping update/registration.`);
    mainWindow.webContents.send("game-update-progress", { 
      game, 
      phase: "skipped", 
      percent: 0, 
      message: "Service file not found, update skipped" 
    });
    return { status: "skipped", message: "Service file not found" };
  }

  return new Promise((resolve, reject) => {
    https.get(link, res => {
      const total = parseInt(res.headers["content-length"] || "0", 10);
      let received = 0;
      const fileStream = fs.createWriteStream(zipPath);

      res.on("data", chunk => {
        received += chunk.length;
        fileStream.write(chunk);
        if (total) {
          const percent = Math.round((received / total) * 100);
          mainWindow.webContents.send("game-update-progress", { game, phase: "downloading", percent });
        }
      });

      res.on("end", () => {
        fileStream.end();
        mainWindow.webContents.send("game-update-progress", { game, phase: "extracting", percent: 100 });

        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: dir }))
          .on("close", () => {
            fs.unlinkSync(zipPath);

            // ✅ Update marker file only if it already existed
            const markerData = { game, version, dir };
            fs.writeFileSync(markerFile, JSON.stringify(markerData, null, 2));

            mainWindow.webContents.send("game-update-progress", { game, phase: "done", percent: 100 });
            resolve({ status: "updated" });
          })
          .on("error", err => reject({ status: "error", message: err.message }));
      });

      res.on("error", err => reject({ status: "error", message: err.message }));
    });
  });
});