const fs = require('fs');
const path = require('path');
const https = require('https');
const unzipper = require('unzipper');

const remoteRegistryUrl = "https://raw.githubusercontent.com/Pranal394/Shardschecker/main/game-versions.json";

function fetchRemoteRegistry() {
  return new Promise((resolve, reject) => {
    https.get(remoteRegistryUrl, res => {
      let data = "";
      res.on("data", chunk => (data += chunk));
      res.on("end", () => resolve(JSON.parse(data)));
      res.on("error", reject);
    }).on("error", reject);
  });
}

async function checkGameUpdates(localGames) {
  const remoteRegistry = await fetchRemoteRegistry();
  const updates = [];

  for (const g of localGames) {
    const markerFile = path.join(g.dir, "ShardsConnect-Service.json");
    if (!fs.existsSync(markerFile)) continue;

    const localData = JSON.parse(fs.readFileSync(markerFile, "utf8"));
    const remoteData = remoteRegistry[g.game];

    if (remoteData && localData.version !== remoteData.version) {
      updates.push({
        game: g.game,
        localVersion: localData.version,
        remoteVersion: remoteData.version,
        link: remoteData.link,
        dir: g.dir
      });
    }
  }
  return updates;
}

function runGameUpdate(game, dir, link, remoteVersion, onProgress) {
  const zipPath = path.join(__dirname, `${game}-update.zip`);

  return new Promise((resolve, reject) => {
    https.get(link, res => {
      const total = parseInt(res.headers['content-length'] || '0', 10);
      let received = 0;
      const fileStream = fs.createWriteStream(zipPath);

      res.on('data', chunk => {
        received += chunk.length;
        fileStream.write(chunk);
        if (total) {
          const percent = Math.round((received / total) * 100);
          onProgress({ phase: 'downloading', percent });
        }
      });

      res.on('end', () => {
        fileStream.end();
        onProgress({ phase: 'extracting', percent: 100 });

        fs.createReadStream(zipPath)
          .pipe(unzipper.Extract({ path: dir }))
          .on('close', () => {
            fs.unlinkSync(zipPath);
            const markerFile = path.join(dir, "ShardsConnect-Service.json");
            const markerData = { game, version: remoteVersion, dir };
            fs.writeFileSync(markerFile, JSON.stringify(markerData, null, 2));
            onProgress({ phase: 'done', percent: 100 });
            resolve({ status: "updated" });
          })
          .on('error', err => reject({ status: "error", message: err.message }));
      });

      res.on('error', err => reject({ status: "error", message: err.message }));
    });
  });
}

module.exports = { checkGameUpdates, runGameUpdate };